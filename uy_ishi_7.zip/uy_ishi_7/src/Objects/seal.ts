const obj = {
    name: "bilol",
    age: 12,
    gender: "M"
  }
  
  ///Object Seal
  Object.seal(obj)
  
  
  // obj.isStudent = "a"
  // obj.name = "a"
  